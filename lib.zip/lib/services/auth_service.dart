import 'dart:convert';
import 'package:flutter_hackathon/modele/user.dart';
import 'package:http/http.dart' as http;


class AuthService {
  static const String _baseUrl = 'http://192.168.23.48/api';
  final http.Client client;

  AuthService({required this.client});

  Future<User> login(String email, String password) async {
    final response = await client.post(
      Uri.parse('$_baseUrl/login'),
      headers: {'Content-Type': 'application/json'},
      body: jsonEncode({'email': email, 'password': password}),
    );

    if (response.statusCode == 200) {
      return User.fromJson(jsonDecode(response.body));
    } else if (response.statusCode == 401 || response.statusCode == 404) {
      throw Exception('Paire login/mot de passe incorrecte');
    } else {
      throw Exception('Erreur de connexion');
    }
  }

  Future<User> register(String name, String email, String password) async {
    final response = await client.post(
      Uri.parse('$_baseUrl/register'),
      headers: {'Content-Type': 'application/json'},
      body: jsonEncode({
        'name': name,
        'email': email,
        'password': password,
      }),
    );

    if (response.statusCode == 200) {
      return User.fromJson(jsonDecode(response.body));
    } else {
      throw Exception('Erreur lors de l\'inscription');
    }
  }

  Future<User?> checkAuth(String token) async {
    final response = await client.get(
      Uri.parse('$_baseUrl/user'),
      headers: {'Authorization': 'Bearer $token'},
    );

    if (response.statusCode == 200) {
      return User.fromJson(jsonDecode(response.body));
    }
    return null;
  }

  Future<void> logout(String token) async {
    await client.post(
      Uri.parse('$_baseUrl/logout'),
      headers: {'Authorization': 'Bearer $token'},
    );
  }
}